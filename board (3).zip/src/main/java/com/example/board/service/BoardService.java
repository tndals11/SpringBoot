package com.example.board.service;

import com.example.board.dto.BoardDto;
import com.example.board.mappers.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BoardService {

    @Autowired
    BoardMapper boardMapper;


    // 검색 메소드

    public List<BoardDto> getSearch(String searchType, String words ) {
        Map<String, Object> map = new HashMap<>();

        String searchQuery = "";

        // searchType
        // subject, writer => where = 이라는 쿼리문이 동일하기 때문에 묶는다
        if (searchType.equals("subject") || searchType.equals("writer")) {
            // WHERE subject = ''
            // WHERE writer = ''
            searchQuery = "WHERE " + searchType + " = '" + words + "'";

        } else if (searchType.equals("content")) {
            // WHERE content LIKE '%비서실'
            // '%"+words+"%' => mysql문 안에 변수 값을 넣을때
            searchQuery  = "WHERE " + searchType + " LIKE '%" + words + "%'";

        } else {
            searchQuery = "";
        }

        map.put("searchQuery", searchQuery);

        return  boardMapper.getList(map) ;
    }

    public int getSearchCnt(String searchType, String words ) {
        Map<String, Object> map = new HashMap<>();

        String searchQuery = "";

        // searchType
        // subject, writer => where = 이라는 쿼리문이 동일하기 때문에 묶는다
        if (searchType.equals("subject") || searchType.equals("writer")) {
            // WHERE subject = ''
            // WHERE writer = ''
            searchQuery = "WHERE " + searchType + " = '" + words + "'";

        } else if (searchType.equals("content")) {
            // WHERE content LIKE '%비서실'
            // '%"+words+"%' => mysql문 안에 변수 값을 넣을때
            searchQuery  = "WHERE " + searchType + " LIKE '%" + words + "%'";

        } else {
            searchQuery = "";
        }

        map.put("searchQuery", searchQuery);

        // 갯수를 세야하기 때문에 Count로 간다
        return  boardMapper.getListCount(map);
    }

    public void  setDelete( int id ) {

        if ( id > 0 ) {

            //file
            BoardDto bd =  boardMapper.getView(id);

            // db삭제
            boardMapper.setDelete(id);

            // 절대경로
              String removeFile = bd.getSavedFilePathName(); // c로 시작하는 절대경로 + 파일이름
            // 상대경로
//             String removeFile = "src/main/resources/static/upload/" + bd.getFolderName() + "/" + bd.getSavedFileName();
            // File 객체는 생성 또는 삭제할 준비
            File f = new File( removeFile );
            if( f.exists() ) {
                boolean result = f.delete();

                if (result) {
                    System.out.println("파일이 삭제되었습니다.");
                } else {
                    System.out.println("파일이 존재하지않습니다.");
                }
            }
        }
    }
}
