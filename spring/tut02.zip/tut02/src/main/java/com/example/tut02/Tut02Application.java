package com.example.tut02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut02Application {

	public static void main(String[] args) {
		SpringApplication.run(Tut02Application.class, args);
	}

}
