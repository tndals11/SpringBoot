package com.example.tut00;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut00ApplicationTests {

	@Test
	void contextLoads() {
	}

}
