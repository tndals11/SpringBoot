use koreaitdb;

create table temp(
id int not null auto_increment,
subject varchar(255),
grp int, --같은 게시물
seq int, --같은 게시물의 답글
depth int, --들여쓰기
primary key(id)
);

insert into temp values(null, '1번째 게시물', 1, 1, 1);
insert into temp values(null, '2번째 게시물', 2, 1, 1);
insert into temp values(null, '3번째 게시물', 3, 1, 1);

--댓글1
insert into temp values(null, '[철수의 답글]2번째 게시물', 2, 1, 2);
--댓글1의 대댓글
insert into temp values(null, '[영희의 답글]2번째 게시물', 2, 2, 2);
--댓글1의 대댓글(중간에 삽입)
insert into temp values(null, '[철수의 답글에 대한 답글]2번째 게시물', 2, 1, 3);

select * from temp order by grp desc, seq asc;

insert into temp values(null, '[홍길동의 - 1번답글]1번째 게시물', 1, 1, 2);

insert into temp values(null, '[코리아의 - 1번답글]1번째 게시물', 1, 2, 2);

use koreaitdb;

create table board(
id int not null auto_increment,
subject varchar(255) not null,
writer varchar(10) not null,
content text,
visit int,
regdate date,
orgName varchar(255),
savedFileName varchar(255),
savedFilePathName varchar(255),
savedFileSize bigint,
folderName varchar(10),
ext varchar(20),
grp int,
seq int,
depth int,
primary key(id)
);

-- 검색 : 조건(where)

-- subject
 select * from board where subject = '안녕하세요' order by id desc;

-- wrtier
 select count(*) from board where writer = '관리자' order by id desc;

-- content
 select count(*) from board where content like '%안녕%' order by id desc;

select * from board where subject = '2';

select * from board where writer = '관리자'

select * from board where content Like '%안녕%'

select * from board where content Like '%니다.%'

