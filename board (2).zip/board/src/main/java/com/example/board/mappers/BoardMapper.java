package com.example.board.mappers;


import com.example.board.dto.BoardDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface BoardMapper {
    @Insert("INSERT INTO board VALUES(NULL,#{subject},#{writer},#{content}, 0, NOW(), #{orgName}, #{savedFileName}, #{savedFilePathName}, #{savedFileSize}, #{folderName}, #{ext}, #{grp}, 1, 1)")
    void setWrite(BoardDto boardDto);

    // grp에 초기값을 부여해줘야한다
    // ifnull( max(grp) + 1, 1 ) 값이 없으면 + 1
    // max(grp) ifnull 값이 있으면 제일 큰값에 +1
    @Select("SELECT ifnull( max(grp) + 1, 1 ) AS maxGrp FROM board")
    int getMaxGrp();

    @Select("SELECT * FROM board ORDER BY id DESC")
    List<BoardDto> getList();


    @Select("SELECT COUNT(*) FROM board")
    int getListCount();

    @Select("SELECT * FROM board WHERE id = #{id}")
    BoardDto getView(int id);

   @Update("UPDATE board SET visit = visit + 1 WHERE id = #{id}")
    void updateVisit(int id);
}