package com.example.board.config;

import com.example.board.interceptor.SessionCheckInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) { // interceptor
        registry.addInterceptor(new SessionCheckInterceptor()) // new SessionCheckInterceptor => 만들어놨던 interseptor 파일을 불러온다
                .order(1).addPathPatterns("/**") // ("/**") => 전부 안보이게 막는
                .excludePathPatterns("/login") //  .excludePathPatterns 이 페이지만 보여준다고 허용
                .excludePathPatterns("/"); // => index.html주소 허용
                // .excludePathPatterns("/board/**"); // /board/** 파일밑에있는것을 전부 허용
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) { // 폴더 접근권한
        registry.addResourceHandler("/**")
                .addResourceLocations("file:src/main/resources/static/upload/")
                .addResourceLocations("file:///D:/temp/");


    }
}