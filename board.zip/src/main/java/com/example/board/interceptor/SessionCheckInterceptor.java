package com.example.board.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.apache.ibatis.plugin.Intercepts;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;


@Component
public class SessionCheckInterceptor implements HandlerInterceptor { // 구현 Override를 해서 사용해주어야한다
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String reqURI = request.getRequestURI(); // => 어떤 주소로 접속했는지 확인
        System.out.println(reqURI);

        // request 서버로부터 전달
        // response 서버로 전달
        HttpSession hs = request.getSession(); // => session
        // LoginInfo(userid, passwd, nam...) - 객체
        if ( hs == null || hs.getAttribute("LoginInfo") == null ) { // session을 체크한다
            System.out.println("You are not Incorrectly");
            response.sendRedirect("/login?redirectURI=" + reqURI); // => 잘못된 접속이면 팅겨낸다
            return false;
        }

        return true;
    }
}
