package com.example.multiple.controller;

import com.example.multiple.dto.ConfigDto;
import com.example.multiple.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
public class ConfigController {

    // C -> S -> M
    // C <- S <- M

    @Autowired
    ConfigService configService;

    @GetMapping("/config/configList")
    public String getConfigList(Model model) {
        List<ConfigDto> config =  configService.getConfigList();

        model.addAttribute("config", config);
        return "config/configList";
    }

    @GetMapping("/config/configWrite")
    public String getConfigWrite() {

        return "config/configWrite";
    }

    @PostMapping("/config/configWrite")
    public String setConfigWrite(@ModelAttribute ConfigDto configDto) {
        configService.setConfig(configDto);

        // 게시판 코드를 이용해서 3개의 테이블을 만든다
        // insert구문에 같이 넣어준다
        configService.makeBoard(configDto.getConfigCode());
        configService.makeFile(configDto.getConfigCode());
        configService.makeComment(configDto.getConfigCode());

        return "redirect:/config/configList";
    }


    // ajax를 이용해서 아이디 검사
    @GetMapping("/config/checkConfigCode")
    @ResponseBody
    public Map<String, Object> getCheckConfigCode(@RequestParam String configCode) {

        int checkCode = configService.getCheckConfigCode(configCode);
        return Map.of("checkCode", checkCode);
    }
    

    // 색상 바꾸기
    @GetMapping("/config/colorChange")
    @ResponseBody
    public Map<String, Object> getColorChange(int id, String color) {

        if ( id > 0 && !color.equals("")) {
            configService.getColorChange(id, color);
            return Map.of("msg", "success");
        }
        return Map.of("msg", "failure");
    }


    @GetMapping("/config/deleteConfig")
    @ResponseBody
    public Map<String, Object> getDeleteConfig(@RequestParam String configCode) {

        if ( !configCode.isEmpty() ) {
            configService.deleteConfig(configCode);
            configService.dropBoard(configCode);
            configService.dropFiles(configCode);
            configService.dropComment(configCode);
            return Map.of("msg", "success");
        }
        return Map.of("msg", "failure");
    }
    
}
