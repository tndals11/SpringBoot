package com.example.board.service;

import com.example.board.dto.BoardDto;
import com.example.board.dto.PageDto;
import com.example.board.mappers.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BoardService {

    @Autowired
    BoardMapper boardMapper;

    // * 페이지 알고리즘 구현 */
    public PageDto BoardPageCalc(int page) {
        PageDto pageDto = new PageDto();

        int totalCount = boardMapper.totalCount();
        // Math.ceil() 소수점을 강제로 1로 만든다
        int totalPage = (int)Math.ceil((double) totalCount / pageDto.getPageCount());
        int startPage = ((int) (Math.ceil( (double) page) / pageDto.getBlockCOunt()) -1) * pageDto.getPage() + 1;

        int endPage = startPage + pageDto.getBlockCOunt() - 1;

        // 끝 페이지 수가 전체 페이지 수 보다 크면
        if ( endPage > totalPage ) {
            endPage = totalPage;
        }

        // dto에 값을 보내주는
        pageDto.setPage(page);
        pageDto.setStartPage(startPage);
        pageDto.setEndPage(endPage);
        pageDto.setTotalPage(totalPage);
        return pageDto;
    }

    // 계산한 페이지 값을  select 보내기 limit


    // 다운로드할때 필요하다

    // 검색 메소드

    public List<BoardDto> getSearch(int page, String searchType, String words) {
        Map<String, Object> map = new HashMap<>();

        String searchQuery = "";

        // searchType
        // subject, writer => where = 이라는 쿼리문이 동일하기 때문에 묶는다
        if (searchType.equals("subject") || searchType.equals("writer")) {
            // WHERE subject = ''
            // WHERE writer = ''
            searchQuery = "WHERE " + searchType + " = '" + words + "'";

        } else if (searchType.equals("content")) {
            // WHERE content LIKE '%비서실'
            // '%"+words+"%' => mysql문 안에 변수 값을 넣을때
            searchQuery  = "WHERE " + searchType + " LIKE '%" + words + "%'";

        } else {
            searchQuery = "";
        }

        PageDto pageDto = new PageDto();
        //limit 시작, 개수
        // LIMIT 0, 3
        // LIMIT 3, 3
        // LIMIT 6, 3
        int startNum = (page - 1) * pageDto.getPageCount();

        map.put("searchQuery", searchQuery);
        map.put("startNum", startNum);
        map.put("offset", pageDto.getPageCount());

        System.out.println(pageDto);
        System.out.println(startNum);

        return  boardMapper.getList(map) ;
    }

    public int getSearchCnt(String searchType, String words ) {
        Map<String, Object> map = new HashMap<>();

        String searchQuery = "";

        // searchType
        // subject, writer => where = 이라는 쿼리문이 동일하기 때문에 묶는다
        if (searchType.equals("subject") || searchType.equals("writer")) {
            // WHERE subject = ''
            // WHERE writer = ''
            searchQuery = "WHERE " + searchType + " = '" + words + "'";

        } else if (searchType.equals("content")) {
            // WHERE content LIKE '%비서실'
            // '%"+words+"%' => mysql문 안에 변수 값을 넣을때
            searchQuery  = "WHERE " + searchType + " LIKE '%" + words + "%'";

        } else {
            searchQuery = "";
        }

        map.put("searchQuery", searchQuery);

        // 갯수를 세야하기 때문에 Count로 간다
        return  boardMapper.getListCount(map);
    }

    public void  setDelete( int id ) {

        if ( id > 0 ) {

            //file
            BoardDto bd =  boardMapper.getView(id);

            // db삭제
            boardMapper.setDelete(id);

            // 절대경로
              String removeFile = bd.getSavedFilePathName(); // c로 시작하는 절대경로 + 파일이름

            // 첨부파일의 존재여부를 확인하는 코드
            if( removeFile != null) {
                File f = new File( removeFile );
                if( f.exists() ) {
                    f.exists();
                }
            }

            // 상대경로
            //  String removeFile = "src/main/resources/static/upload/" + bd.getFolderName() + "/" + bd.getSavedFileName();
            // File 객체는 생성 또는 삭제할 준비

        }
    }
}
